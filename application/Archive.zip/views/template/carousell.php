
  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex flex-column justify-content-center align-items-center">
    <div class="container text-center text-md-left" data-aos="fade-up">
      <h1>Selamat Datang di <span>Les Privat</span></h1>
      <h2>Kami adalah tim guru yang mengajar siswa dengan semangat, visi, dan misi untuk menjadi pemenang dan cerdas. Buat akun dan BERGABUNG DENGAN KAMI!</h2>
      <!-- <a href="#about" class="btn-get-started scrollto">Get Started</a> -->
    </div>
  </section><!-- End Hero -->